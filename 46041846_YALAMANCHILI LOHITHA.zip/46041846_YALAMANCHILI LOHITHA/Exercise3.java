package Lab5;
public class Exercise3 {
public static void main(String args[]) {
Exercise3 le3 = new Exercise3();
try {
System.out.println(le3.employeeSalary(5000));
System.out.println(le3.employeeSalary(2500));
}
catch(EmployeeException e) {
System.out.println(e);
}
}
public float employeeSalary(float salary) throws EmployeeException {
if(salary<3000) {
throw new EmployeeException("Salary is less than 3000");
}
else
System.out.println("Salary is...");
return salary;
}
}
