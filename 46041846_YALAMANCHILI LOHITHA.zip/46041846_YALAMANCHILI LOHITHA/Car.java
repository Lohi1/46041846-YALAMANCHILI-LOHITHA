package today;
import java.util.HashMap;
import java.util.Map;

public class Car
{
  public static void main(String[] args)
  {
	  New1 c1=new New1 ("Swift");
	  New1 c2=new New1("Swift");
	  System.out.println(c1.equals(c2));
	  
	  Map<New1,Carprice> Cardetails=new HashMap<New1,Carprice>();
    
	  Cardetails.put(c2, new Carprice());
	  Cardetails.put(c2, new Carprice());
	  
	  System.out.println(Cardetails.size());
	  
	  
  }
}