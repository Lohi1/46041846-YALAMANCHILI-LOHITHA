
package com.cg.eis.service;

import java.util.Scanner;

import com.cg.eis.bean.Employee;

public class Service implements EmployeeService{
	Scanner sc=new Scanner(System.in);
	Employee employee=new Employee();
	public void information()
	{
		System.out.println("Enter the employee details :");
		System.out.println("Enter the employee name :");
		String name=sc.next();
		employee.setName(name);
		System.out.println("Enter the employee id :");
		int id=sc.nextInt();
		employee.setId(id);
		System.out.println("Enter the employee salary :");
		float salary=sc.nextFloat();
		employee.setSalary(salary);
		System.out.println("Enter the employee designation :");
		String designation=sc.next();
		employee.setDesignation(designation);

	}
	public void insuranceScheme()
	{
		if((employee.getSalary()>=40000)||(employee.getDesignation()=="Senior Analyst"))
		{
			System.out.println("Life insurance");
		}
		else if((employee.getSalary()>=20000)||(employee.getDesignation()=="Analyst"))
		{
			System.out.println("Life insurance and medical insurance");
		}
		else
		{
			System.out.println("No insurance");
		}
	}
	public void display()
	{
		System.out.println("Employee name :"+employee.getName());
		System.out.println("Employee id :"+employee.getId());
		System.out.println("Employee salary :"+employee.getSalary());
		System.out.println("Employee designation :"+employee.getDesignation());
	}
}